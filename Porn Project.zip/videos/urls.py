from django.urls import path
from . import views

app_name = 'videos'

urlpatterns = [
    # API-powered views (main site)
    path('', views.home_view, name='home'),
    path('watch/<str:video_id>/', views.watch_view, name='watch'),
    path('categories/', views.category_list_view, name='categories'),
    path('category/<slug:slug>/', views.category_detail_view, name='category'),
    path('search/', views.search_view, name='search'),
    path('trending/', views.trending_view, name='trending'),
    path('newest/', views.newest_view, name='newest'),
    path('top-rated/', views.top_rated_view, name='top_rated'),

    # Hentai section (Hanime.tv API)
    path('hentai/', views.hentai_home_view, name='hentai_home'),
    path('hentai/browse/', views.hentai_browse_view, name='hentai_browse'),
    path('hentai/trending/', views.hentai_trending_view, name='hentai_trending'),
    path('hentai/newest/', views.hentai_newest_view, name='hentai_newest'),
    path('hentai/watch/<slug:slug>/', views.hentai_watch_view, name='hentai_watch'),
    path('hentai/tags/', views.hentai_tags_view, name='hentai_tags'),
    path('hentai/tag/<slug:tag>/', views.hentai_tag_view, name='hentai_tag'),
    path('hentai/search/', views.hentai_search_view, name='hentai_search'),

    # RedTube section
    path('redtube/', views.redtube_home_view, name='redtube_home'),
    path('redtube/browse/', views.redtube_browse_view, name='redtube_browse'),
    path('redtube/watch/<str:video_id>/', views.redtube_watch_view, name='redtube_watch'),
    path('redtube/search/', views.redtube_search_view, name='redtube_search'),

    # Pornstars section
    path('pornstars/', views.pornstars_view, name='pornstars'),
    path('pornstar/<slug:slug>/', views.pornstar_detail_view, name='pornstar_detail'),

    # Local uploads (for your own videos)
    path('local/', views.LocalVideoListView.as_view(), name='local_videos'),
    path('local/<slug:slug>/', views.LocalVideoDetailView.as_view(), name='local_watch'),

    # Interactions (for local videos)
    path('like/<slug:slug>/', views.like_video, name='like'),
    path('dislike/<slug:slug>/', views.dislike_video, name='dislike'),
    path('favorite/<slug:slug>/', views.toggle_favorite, name='favorite'),
    path('comment/<slug:slug>/', views.add_comment, name='comment'),
]
